#!/bin/sh

rm *.o *.d ./parser *.output cool-flex-lexer.cc cool-bison-parser.*


